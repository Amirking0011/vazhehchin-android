# تبدیل پروژه واژه‌چین به APK

این پوشه **سورس کامل اپلیکیشن اندروید** است؛ فایل APK داخل این ZIP نیست. برای تولید فایل نصب‌شدنی به Android SDK و Gradle نیاز است. APK آزمایشی را می‌توان با یکی از دو راه ساخت:

## روش ۱: Android Studio روی کامپیوتر

1. فایل ZIP را استخراج کنید و پوشه `vazhehchin-android` را با **File → Open** در Android Studio باز کنید.
2. Android Studio باید Android SDK Platform 35 و Build Tools 35.0.0 را نصب کرده باشد. برای پروژه Java 17 و Gradle 8.9 با پلاگین اندروید 8.7.3 لازم است.
3. بعد از Gradle Sync، از منوی **Build → Build Bundle(s) / APK(s) → Build APK(s)** استفاده کنید. (در نسخه‌های مختلف منو ممکن است کمی تفاوت داشته باشد.)
4. فایل نصب‌شدنی در مسیر زیر تولید می‌شود: `app/build/outputs/apk/debug/app-debug.apk`.
5. فایل APK را به گوشی اندروید انتقال دهید؛ در صورت درخواست، اجازه نصب برنامه از همان منبع را فعال کنید.

**توجه:** این نسخه APK امضاشدهٔ **آزمایشی** است و برای انتشار در Google Play باید نسخهٔ release امضاشده و AAB جداگانه ساخته شود. در فایل پروژه، `gradle-wrapper.jar` بسته‌بندی نشده؛ اگر Android Studio نتواند Gradle را همگام کند، Gradle 8.9 را در تنظیمات Gradle آن نصب/انتخاب کنید. 

## روش ۲: ساخت خودکار در GitHub Actions (بدون نصب Android Studio)

1. محتوای همین پوشه Android را در یک مخزن GitHub قرار دهید. فولدر مخفی `.github` نیز باید همراه پروژه باشد.
2. در GitHub به زبانه **Actions** و سپس **Build Vazhehchin Android APK** بروید.
3. روی **Run workflow** بزنید و ساخت را اجرا کنید.
4. بعد از اتمام موفق اجرای workflow، فایل **Vazhehchin-Android-Debug-APK** را از قسمت Artifacts دانلود و استخراج کنید. داخل آن `app-debug.apk` قرار دارد.

در workflow فایل `.github/workflows/build-android-apk.yml` پلتفرم Android 35، ابزار ساخت 35.0.0 و Gradle 8.9 نصب و سپس APK ساخته می‌شود. برای اجرای Actions ممکن است نیاز باشد قابلیت Actions در مخزن GitHub فعال شود.

## محدودیت‌های نسخه

- بازی و تصاویر و موسیقی آفلاین در اپ قرار دارند. مسابقهٔ واقعی دو گوشی تنها بعد از استقرار سرور HTTPS و پیکربندی `GAME_SERVER_URL` در `app/build.gradle` امکان دارد.
- سکه‌ها، واریز و برداشت وجه در نسخهٔ آماده‌شده نمایشی هستند؛ هیچ پرداخت بانکی واقعی یا جایزهٔ نقدی متصل نشده است.
- APK در این محیط ساخته یا روی گوشی واقعی اجرا نشده است، چون Android SDK و Gradle قابل دسترسی نبودند.
