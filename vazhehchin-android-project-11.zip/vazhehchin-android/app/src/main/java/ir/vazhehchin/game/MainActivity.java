package ir.vazhehchin.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Gravity;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;

import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.HashMap;

/**
 * Vazhehchin 4.1: always open the ORIGINAL offline-capable home screen.
 * Only tapping the Online tab starts a connection attempt in a separate WebView.
 * Failure shows a dialog OVER the original home; it never replaces the home screen.
 * The remote screen appears only after the actual backend HTML is verified.
 */
public final class MainActivity extends Activity {
    private static final String SITE_HOST="appassets.androidplatform.net";
    private static final String HOME_URL="https://appassets.androidplatform.net/assets/index.html";
    private static final String BUILD_VERSION="4.1.0";
    private static final int PHOTO_PICKER_REQUEST=621;

    private WebView homeWeb;
    private WebView onlineWeb;
    private LinearLayout onlineScreen;
    private FrameLayout loadingScreen;
    private TextView waitingText;
    private ValueCallback<Uri[]> photoPickerCallback;
    private String onlineOrigin;
    private boolean onlineRequested=false;
    private boolean onlineFailed=false;
    private int attempt=0;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private Runnable deadline;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(236,245,255));
        getWindow().setNavigationBarColor(Color.rgb(236,245,255));
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        String server=BuildConfig.GAME_SERVER_URL.trim();
        Uri configured=Uri.parse(server);
        onlineOrigin="https".equals(configured.getScheme()) && configured.getHost()!=null
            ? "https://"+configured.getAuthority() : null;

        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(236,245,255));
        homeWeb=new WebView(this);
        homeWeb.setBackgroundColor(Color.rgb(236,245,255));
        configure(homeWeb);
        homeWeb.setWebViewClient(new LocalClient());
        root.addView(homeWeb,new FrameLayout.LayoutParams(-1,-1));

        // Online view is INDEPENDENT of the local home, preserving its state and coins.
        onlineScreen=new LinearLayout(this);
        onlineScreen.setOrientation(LinearLayout.VERTICAL);
        onlineScreen.setVisibility(View.GONE);
        onlineScreen.setBackgroundColor(Color.rgb(236,245,255));
        FrameLayout.LayoutParams full=new FrameLayout.LayoutParams(-1,-1);
        root.addView(onlineScreen,full);

        Button home=new Button(this);
        home.setAllCaps(false);
        home.setText("↩ بازگشت به صفحه اصلی واژه‌چین");
        home.setTextSize(15);
        home.setTextColor(Color.rgb(18,64,108));
        home.setBackgroundColor(Color.rgb(220,237,255));
        onlineScreen.addView(home,new LinearLayout.LayoutParams(-1,dp(49)));
        home.setOnClickListener(v->returnHome());
        onlineWeb=new WebView(this);
        onlineWeb.setBackgroundColor(Color.rgb(236,245,255));
        configure(onlineWeb);
        onlineWeb.setWebViewClient(new OnlineClient());
        onlineScreen.addView(onlineWeb,new LinearLayout.LayoutParams(-1,0,1));

        // Loading overlay only exists AFTER the player taps the Online tab.
        loadingScreen=new FrameLayout(this);
        loadingScreen.setBackgroundColor(0xF3EDF5FF);
        loadingScreen.setVisibility(View.GONE);
        root.addView(loadingScreen,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(20),dp(30),dp(20),dp(30));
        FrameLayout.LayoutParams boxParams=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        loadingScreen.addView(box,boxParams);
        waitingText=new TextView(this);
        waitingText.setTextSize(19);
        waitingText.setTextColor(Color.rgb(24,55,99));
        waitingText.setGravity(Gravity.CENTER);
        waitingText.setText("⏳ در حال اتصال به مسابقهٔ آنلاین...\nسرور ممکن است برای اتصال اولیه کمی زمان بخواهد.");
        box.addView(waitingText,new LinearLayout.LayoutParams(-1,-2));
        Button cancel=new Button(this);
        cancel.setText("بازگشت به بازی");
        LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(-1,-2);
        c.topMargin=dp(18);
        box.addView(cancel,c);
        cancel.setOnClickListener(v->returnHome());

        // Android 15 respects system bars without changing the design.
        if(Build.VERSION.SDK_INT >= 35){
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController ctr=getWindow().getInsetsController();
            if(ctr!=null){
                int mask=WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS |
                         WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                ctr.setSystemBarsAppearance(mask,mask);
            }
            root.setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets safe=insets.getInsets(
                    WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(safe.left,safe.top,safe.right,safe.bottom);
                return insets;
            });
        }
        setContentView(root);
        // No network access or loading overlay needed for startup.
        homeWeb.loadUrl(HOME_URL+"?apk_build="+BUILD_VERSION);
    }

    private void configure(WebView web){
        WebSettings config=web.getSettings();
        config.setJavaScriptEnabled(true);
        config.setDomStorageEnabled(true);
        config.setCacheMode(WebSettings.LOAD_NO_CACHE);
        config.setMediaPlaybackRequiresUserGesture(false);
        config.setAllowFileAccess(false);
        config.setAllowContentAccess(true);
        config.setJavaScriptCanOpenWindowsAutomatically(false);
        config.setSupportMultipleWindows(false);
        config.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> callback,
                                                          FileChooserParams params){
                if(photoPickerCallback!=null)photoPickerCallback.onReceiveValue(null);
                photoPickerCallback=callback;
                Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                try{
                    startActivityForResult(Intent.createChooser(intent,"انتخاب عکس پروفایل"),PHOTO_PICKER_REQUEST);
                    return true;
                }catch(ActivityNotFoundException ex){
                    photoPickerCallback=null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });
    }

    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private boolean isOnline(Uri uri){
        return uri!=null && onlineOrigin!=null &&
               "https".equals(uri.getScheme()) &&
               Uri.parse(onlineOrigin).getAuthority().equals(uri.getAuthority());
    }
    private boolean isBundled(Uri uri){
        return uri!=null && "https".equals(uri.getScheme())
               && SITE_HOST.equals(uri.getHost());
    }
    private boolean hasInternetNetwork(){
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if(cm==null)return true;
        Network n=cm.getActiveNetwork();
        NetworkCapabilities caps=n==null?null:cm.getNetworkCapabilities(n);
        return caps!=null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }
    private void clearDeadline(){
        if(deadline!=null){handler.removeCallbacks(deadline);deadline=null;}
    }
    private void beginOnline(){
        if(onlineRequested)return;
        if(onlineOrigin==null){showOfflineError("آدرس سرور مسابقه تنظیم نشده است.");return;}
        if(!hasInternetNetwork()){
            showOfflineError("اینترنت شما قطع است. اینترنت یا VPN را روشن کن و دوباره تلاش کن.");
            return;
        }
        onlineRequested=true;
        onlineFailed=false;
        int current=++attempt;
        waitingText.setText("⏳ در حال اتصال به مسابقهٔ آنلاین...\nدر اتصال اول ممکن است سرور کمی دیر پاسخ دهد.");
        loadingScreen.setVisibility(View.VISIBLE);
        onlineWeb.loadUrl(onlineOrigin+"/?apk_build="+BUILD_VERSION);
        clearDeadline();
        deadline=()->{
            if(current==attempt && onlineRequested && !onlineFailed &&
                onlineScreen.getVisibility()!=View.VISIBLE){
                failOnline("پاسخی از سرور مسابقه دریافت نشد. اینترنت یا VPN را بررسی کن.");
            }
        };
        handler.postDelayed(deadline,90000); // Free Render instance may be asleep.
    }
    private void showOfflineError(String message){
        if(isFinishing()||isDestroyed())return;
        new AlertDialog.Builder(this)
            .setTitle("خطای اتصال آنلاین")
            .setMessage(message)
            .setPositiveButton("تلاش دوباره",(dlg,which)->beginOnline())
            .setNegativeButton("بازگشت به بازی",(dlg,which)->dlg.dismiss())
            .show();
    }
    private void failOnline(String message){
        if(!onlineRequested || onlineFailed)return;
        onlineFailed=true;
        onlineRequested=false;
        ++attempt;
        clearDeadline();
        onlineWeb.stopLoading();
        loadingScreen.setVisibility(View.GONE);
        onlineScreen.setVisibility(View.GONE);
        homeWeb.setVisibility(View.VISIBLE);
        homeWeb.onResume();
        showOfflineError(message);
    }
    private void returnHome(){
        onlineRequested=false;
        onlineFailed=false;
        ++attempt;
        clearDeadline();
        onlineWeb.stopLoading();
        // Unload live matchmaking while keeping the original home WebView intact.
        onlineWeb.loadUrl("about:blank");
        onlineScreen.setVisibility(View.GONE);
        loadingScreen.setVisibility(View.GONE);
        homeWeb.setVisibility(View.VISIBLE);
        homeWeb.onResume();
    }

    private final class LocalClient extends WebViewClient {
        @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
            Uri u=request.getUrl();
            if("vazhehchin".equals(u.getScheme()) && "online".equals(u.getHost())){
                beginOnline();return true;
            }
            if(isBundled(u)&&u.getPath()!=null&&u.getPath().startsWith("/assets/"))return false;
            return true;
        }
        @Override public void onPageFinished(WebView view,String url){
            // This runs for all bundled reloads, with NO startup network check.
            if(url!=null&&url.startsWith(HOME_URL)){
                view.evaluateJavascript(
                    "(function(){var tab=document.getElementById('onlineTab');"+
                    "if(!tab)return;tab.hidden=false;"+
                    "if(tab.dataset.nativeOnlineLink)return;tab.dataset.nativeOnlineLink='1';"+
                    "tab.addEventListener('click',function(e){e.preventDefault();"+
                    "e.stopImmediatePropagation();location.href='vazhehchin://online';},true);})()",null);
            }
        }
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if ("https".equals(uri.getScheme())
                && SITE_HOST.equals(uri.getHost())
                && "/assets/index.html".equals(uri.getPath())) {
                try {
                    InputStream html = getAssets().open("index.html");
                    return new WebResourceResponse("text/html", "UTF-8", html);
                } catch (IOException ignored) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                        new ByteArrayInputStream("Game content missing".getBytes()));
                }
            }
            // Bundle actual photo puzzles locally; never fetch or expose arbitrary asset paths.
            if("https".equals(uri.getScheme()) && SITE_HOST.equals(uri.getHost())
                && uri.getPath() != null && uri.getPath().matches("/assets/photos/[a-zA-Z0-9_-]+\\.jpg")) {
                String assetPath = uri.getPath().substring("/assets/".length());
                try {
                    InputStream photo = getAssets().open(assetPath);
                    return new WebResourceResponse("image/jpeg", null, photo);
                } catch (IOException ignored) {
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                }
            }
            if("https".equals(uri.getScheme()) && SITE_HOST.equals(uri.getHost())
                && "/assets/music/blue-garden.mp3".equals(uri.getPath())) {
                try {
                    String assetPath = "music/blue-garden.mp3";
                    InputStream audio=getAssets().open(assetPath);
                    long total=audio.available();
                    if(total<=0){audio.close();throw new IOException("invalid size");}
                    long start=0,end=total-1;
                    boolean partial=false;
                    String range=request.getRequestHeaders().get("Range");
                    if(range != null && range.matches("bytes=\\d+-\\d*")) {
                        String[] numbers=range.substring(6).split("-",-1);
                        start=Long.parseLong(numbers[0]);
                        if(!numbers[1].isEmpty())end=Long.parseLong(numbers[1]);
                        end=Math.min(end,total-1);
                        if(start > end || start>=total)throw new IOException("range outside asset");
                        partial=true;
                    }
                    long skip=start;
                    while(skip>0){
                        long advanced=audio.skip(skip);
                        if(advanced<=0){audio.close();throw new IOException("seek failed");}
                        skip-=advanced;
                    }
                    Map<String,String> headers=new HashMap<>();
                    headers.put("Accept-Ranges","bytes");
                    headers.put("Content-Length",Long.toString(end-start+1));
                    if(partial)headers.put("Content-Range","bytes "+start+"-"+end+"/"+total);
                    final long remainingBytes = end-start+1;
                    return new WebResourceResponse("audio/mpeg",null,
                        partial?206:200,partial?"Partial Content":"OK",headers,
                        new java.io.FilterInputStream(audio){
                            long remaining=remainingBytes;
                            @Override public int read() throws IOException {
                                if(remaining<=0)return -1;
                                int v=super.read();if(v>=0)remaining--;return v;
                            }
                            @Override public int read(byte[] b,int off,int len) throws IOException {
                                if(remaining<=0)return -1;
                                int n=super.read(b,off,(int)Math.min(len,remaining));
                                if(n>0)remaining-=n;
                                return n;
                            }
                        });
                }catch(Exception ignored){
                    return new WebResourceResponse("text/plain","UTF-8",
                        new ByteArrayInputStream(new byte[0]));
                }
            }
            if(onlineOrigin != null && "https".equals(uri.getScheme())
                    && Uri.parse(onlineOrigin).getAuthority().equals(uri.getAuthority())) {
                // The deployed server may serve HTML, JS, and same-origin API routes.
                return null;
            }
            // Third-party requests and unknown local paths are blocked.
            return new WebResourceResponse("text/plain", "UTF-8",
                new ByteArrayInputStream(new byte[0]));
        }
    }

    private final class OnlineClient extends WebViewClient {
        @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
            return !isOnline(request.getUrl());
        }
        @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){
            if(onlineRequested && request.isForMainFrame() && isOnline(request.getUrl())){
                String msg=!hasInternetNetwork()
                    ? "اینترنت شما قطع است. اینترنت یا VPN را روشن کن."
                    : "اتصال به سرور مسابقه برقرار نشد (خطای شبکه: "+error.getErrorCode()+"). اینترنت یا VPN را بررسی کن.";
                failOnline(msg);
            }
        }
        @Override public void onReceivedHttpError(WebView view,WebResourceRequest request,WebResourceResponse response){
            if(onlineRequested && request.isForMainFrame() && isOnline(request.getUrl()) && response.getStatusCode()>=400){
                failOnline("سرور مسابقه پاسخ ناموفق داد ("+response.getStatusCode()+"). دوباره تلاش کن.");
            }
        }
        @Override public void onPageFinished(WebView view,String url){
            if(!onlineRequested || onlineFailed || url==null || !isOnline(Uri.parse(url)))return;
            final int thisAttempt=attempt;
            view.evaluateJavascript(
                "(function(){var b=document.getElementById('joinOnlineBtn');return " +
                "document.documentElement.dataset.serverBackend==='true' && !!b && " +
                "b.textContent.indexOf('پیدا کردن حریف')>=0})()", result->{
                    if(thisAttempt!=attempt || !onlineRequested || onlineFailed)return;
                    if(!"true".equals(result)){
                        failOnline("صفحه مسابقه واقعی از سرور دریافت نشد. دوباره تلاش کن.");
                        return;
                    }
                    clearDeadline();
                    loadingScreen.setVisibility(View.GONE);
                    homeWeb.onPause();
                    homeWeb.setVisibility(View.GONE);
                    onlineScreen.setVisibility(View.VISIBLE);
                    view.evaluateJavascript(
                        "(function(){var t=document.getElementById('onlineTab');if(t)t.click()})()",null);
                });
        }
        @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
            // Online responses, websockets/fetch stay same-origin; no third-party traffic.
            if(isOnline(request.getUrl()))return null;
            return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));
        }
    }

    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==PHOTO_PICKER_REQUEST && photoPickerCallback!=null){
            Uri[] chosen=result==RESULT_OK && data!=null && data.getData()!=null
                ? new Uri[]{data.getData()} : null;
            photoPickerCallback.onReceiveValue(chosen);
            photoPickerCallback=null;
        }
    }
    @Override public void onBackPressed(){
        if(onlineRequested || onlineScreen.getVisibility()==View.VISIBLE){returnHome();return;}
        new AlertDialog.Builder(this)
            .setTitle("خروج از واژه‌چین")
            .setMessage("از بازی خارج می‌شوی؟ پیشرفت ذخیره‌شده روی گوشی باقی می‌ماند.")
            .setPositiveButton("خروج",(dialog,w)->finish())
            .setNegativeButton("ادامه بازی",(dialog,w)->dialog.dismiss())
            .show();
    }
    @Override protected void onPause(){
        if(homeWeb!=null)homeWeb.onPause();
        if(onlineWeb!=null)onlineWeb.onPause();
        super.onPause();
    }
    @Override protected void onResume(){
        super.onResume();
        if(homeWeb!=null && onlineScreen!=null && onlineScreen.getVisibility()!=View.VISIBLE)homeWeb.onResume();
        if(onlineWeb!=null && onlineScreen!=null && onlineScreen.getVisibility()==View.VISIBLE)onlineWeb.onResume();
    }
    @Override protected void onDestroy(){
        clearDeadline();
        if(photoPickerCallback!=null){photoPickerCallback.onReceiveValue(null);photoPickerCallback=null;}
        if(homeWeb!=null)homeWeb.destroy();
        if(onlineWeb!=null)onlineWeb.destroy();
        super.onDestroy();
    }
}
