package ir.vazhehchin.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;

import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.HashMap;

/**
 * Android shell for the Persian puzzle and competition game.
 * Loads a configured HTTPS origin for online play, otherwise bundled offline HTML.
 * Never allows insecure HTTP or arbitrary third-party navigation.
 * The secure appassets origin allows localStorage in offline mode.
 */
public final class MainActivity extends Activity {
    private static final String SITE_HOST = "appassets.androidplatform.net";
    private static final String HOME_URL = "https://appassets.androidplatform.net/assets/index.html";
    private WebView webView;
    private static final int PHOTO_PICKER_REQUEST = 621;
    private ValueCallback<Uri[]> photoPickerCallback;
    private String onlineOrigin;
    private String homeUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setNavigationBarColor(Color.rgb(236, 245, 255));
        getWindow().setStatusBarColor(Color.rgb(236, 245, 255));

        // Only a production HTTPS origin can enable network matches.
        String config = BuildConfig.GAME_SERVER_URL.trim();
        Uri configured = Uri.parse(config);
        if ("https".equals(configured.getScheme()) && configured.getHost() != null
               ) {
            onlineOrigin = "https://" + configured.getAuthority();
            homeUrl = onlineOrigin + "/";
        } else {
            onlineOrigin = null;
            homeUrl = HOME_URL;
        }
        FrameLayout container = new FrameLayout(this);
        container.setBackgroundColor(Color.rgb(236, 245, 255));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(236, 245, 255));
        container.addView(webView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));

        // Android 15 edge-to-edge: keep game away from status/navigation buttons.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                         | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(mask, mask);
            }
            container.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets safe = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return insets;
            });
        }
        setContentView(container);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        // Play the game's self-generated soundtrack on entry in Android WebView.
        // Mobile browsers may still need one user gesture because of autoplay rules.
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        // Content picker access is required for a user-selected profile picture.
        // Arbitrary local file access remains disabled.
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new OfflineGameClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params){
                if(photoPickerCallback != null) photoPickerCallback.onReceiveValue(null);
                photoPickerCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                try{
                    startActivityForResult(Intent.createChooser(intent,"انتخاب عکس پروفایل"),PHOTO_PICKER_REQUEST);
                    return true;
                }catch(ActivityNotFoundException ex){
                    photoPickerCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });
        webView.loadUrl(homeUrl);
    }

    private final class OfflineGameClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            // No outgoing links or remote navigations: the game is self-contained.
            Uri uri = request.getUrl();
            if (onlineOrigin != null && "https".equals(uri.getScheme())) {
                Uri origin = Uri.parse(onlineOrigin);
                return !origin.getAuthority().equals(uri.getAuthority());
            }
            return !HOME_URL.equals(uri.toString());
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if ("https".equals(uri.getScheme())
                && SITE_HOST.equals(uri.getHost())
                && "/assets/index.html".equals(uri.getPath())) {
                try {
                    InputStream html = getAssets().open("index.html");
                    return new WebResourceResponse("text/html", "UTF-8", html);
                } catch (IOException ignored) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                        new ByteArrayInputStream("Game content missing".getBytes()));
                }
            }
            // Bundle actual photo puzzles locally; never fetch or expose arbitrary asset paths.
            if("https".equals(uri.getScheme()) && SITE_HOST.equals(uri.getHost())
                && uri.getPath() != null && uri.getPath().matches("/assets/photos/[a-zA-Z0-9_-]+\\.jpg")) {
                String assetPath = uri.getPath().substring("/assets/".length());
                try {
                    InputStream photo = getAssets().open(assetPath);
                    return new WebResourceResponse("image/jpeg", null, photo);
                } catch (IOException ignored) {
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                }
            }
            if("https".equals(uri.getScheme()) && SITE_HOST.equals(uri.getHost())
                && "/assets/music/blue-garden.mp3".equals(uri.getPath())) {
                try {
                    String assetPath = "music/blue-garden.mp3";
                    InputStream audio=getAssets().open(assetPath);
                    long total=audio.available();
                    if(total<=0){audio.close();throw new IOException("invalid size");}
                    long start=0,end=total-1;
                    boolean partial=false;
                    String range=request.getRequestHeaders().get("Range");
                    if(range != null && range.matches("bytes=\\d+-\\d*")) {
                        String[] numbers=range.substring(6).split("-",-1);
                        start=Long.parseLong(numbers[0]);
                        if(!numbers[1].isEmpty())end=Long.parseLong(numbers[1]);
                        end=Math.min(end,total-1);
                        if(start > end || start>=total)throw new IOException("range outside asset");
                        partial=true;
                    }
                    long skip=start;
                    while(skip>0){
                        long advanced=audio.skip(skip);
                        if(advanced<=0){audio.close();throw new IOException("seek failed");}
                        skip-=advanced;
                    }
                    Map<String,String> headers=new HashMap<>();
                    headers.put("Accept-Ranges","bytes");
                    headers.put("Content-Length",Long.toString(end-start+1));
                    if(partial)headers.put("Content-Range","bytes "+start+"-"+end+"/"+total);
                    final long remainingBytes = end-start+1;
                    return new WebResourceResponse("audio/mpeg",null,
                        partial?206:200,partial?"Partial Content":"OK",headers,
                        new java.io.FilterInputStream(audio){
                            long remaining=remainingBytes;
                            @Override public int read() throws IOException {
                                if(remaining<=0)return -1;
                                int v=super.read();if(v>=0)remaining--;return v;
                            }
                            @Override public int read(byte[] b,int off,int len) throws IOException {
                                if(remaining<=0)return -1;
                                int n=super.read(b,off,(int)Math.min(len,remaining));
                                if(n>0)remaining-=n;
                                return n;
                            }
                        });
                }catch(Exception ignored){
                    return new WebResourceResponse("text/plain","UTF-8",
                        new ByteArrayInputStream(new byte[0]));
                }
            }
            if(onlineOrigin != null && "https".equals(uri.getScheme())
                    && Uri.parse(onlineOrigin).getAuthority().equals(uri.getAuthority())) {
                // The deployed server may serve HTML, JS, and same-origin API routes.
                return null;
            }
            // Third-party requests and unknown local paths are blocked.
            return new WebResourceResponse("text/plain", "UTF-8",
                new ByteArrayInputStream(new byte[0]));
        }
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PHOTO_PICKER_REQUEST && photoPickerCallback!=null){
            Uri[] selection=null;
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                selection=new Uri[]{data.getData()};
            }
            photoPickerCallback.onReceiveValue(selection);
            photoPickerCallback=null;
        }
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
            .setTitle("خروج از واژه‌چین")
            .setMessage("می‌خواهی از بازی خارج شوی؟ پیشرفتت ذخیره شده است.")
            .setPositiveButton("خروج", (dialog, which) -> finish())
            .setNegativeButton("ادامهٔ بازی", (dialog, which) -> dialog.dismiss())
            .show();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if(photoPickerCallback!=null){photoPickerCallback.onReceiveValue(null);photoPickerCallback=null;}
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
