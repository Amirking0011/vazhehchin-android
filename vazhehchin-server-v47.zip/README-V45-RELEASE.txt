Vazhehchin server v4.5

Server prices: 1 coin = 100 Toman = 1,000 Rial, DISPLAY QUOTE ONLY.
Free online matches: winner with registered account receives 50 virtual coins.
No real purchase, bank payout or cash redemption is enabled.
Source includes old prototype file storage on ephemeral Render free container: not suitable for production custody of coins.
Upload this archive to the GitHub repository AS vazhehchin-server.zip to match the existing Dockerfile.
