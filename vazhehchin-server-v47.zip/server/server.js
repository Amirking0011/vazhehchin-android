'use strict';
/**
 * Vaazhehchin online contest prototype, Node 20+ only, no external dependencies.
 * Demonstration of server-timed two-device matches, central scoring, leaderboard,
 * and pre-review prize requests. NO real-money payout is implemented or enabled.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '127.0.0.1';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'records.json');
const HTML_FILE = path.resolve(__dirname, '../index.html');
const MUSIC_FILE = path.resolve(__dirname, '../music/blue-garden.mp3');
const PROFILE_PHOTO_DIR = path.join(DATA_DIR, 'profile-images');
const QUESTION_COUNT = 20;
const QUESTION_SECONDS = 2; // 20 photos x 2 seconds = 40 seconds total
const QUESTION_TIME_MS = process.env.NODE_ENV==='test' && process.env.TEST_QUESTION_MS
  ? Number(process.env.TEST_QUESTION_MS) : QUESTION_SECONDS*1000;
const ANSWERS = JSON.parse(fs.readFileSync(path.resolve(__dirname,'../puzzles.json'),'utf8')).map(p=>p.answer);
if (ANSWERS.length<QUESTION_COUNT)throw new Error('Online photo bank needs at least 20 pictures');
const PRIZES = { winner:0, runnerUp:0, tie:0 }; // No cash prizes.
const WIN_COINS = 30; // 2-player first place; virtual and non-redeemable.
const COIN_REWARDS = Object.freeze({2:[30,0],4:[50,30,0,0]}); // Rank 1,2,3,4
// Nominal DISPLAY-ONLY rate. No banking or cash redemption is available.
const NOMINAL_TOMAN_PER_COIN = 35;
const NOMINAL_RIALS_PER_COIN = NOMINAL_TOMAN_PER_COIN * 10;
const SESSION_MS = 7 * 24 * 60 * 60 * 1000;
const AVATARS = ['🦊','🐼','🦁','🐱','🦉','🐸','🌟','🎮'];
// Published store quote, INACTIVE until Myket merchant setup and a verified receipt ledger.
// Prices are quoted in toman; Myket product configuration may request rials.
// No client-side purchase report can credit coins.
const SHOP_PACKS = Object.freeze([
  {id:'starter',sku:'coins_100',coins:100,originalPriceToman:3500,priceToman:3500,title:'بستهٔ شروع'},
  {id:'plus',sku:'coins_350',coins:350,originalPriceToman:12250,priceToman:12250,title:'بستهٔ محبوب'},
  {id:'max',sku:'coins_800',coins:800,originalPriceToman:28000,priceToman:28000,title:'بستهٔ ویژه'}
]);
const PAYMENTS_ENABLED = false; // Never set true without authoritative server-side Myket receipt verification.
const BILLING_PROVIDER = 'myket';
const BILLING_SETUP_REQUIRED = true;
const WITHDRAWALS_ENABLED = false;
const authRateBuckets = new Map();
// Demo account storage. Use a real database + independently reviewed auth before production.

// Hard safety boundary: preview figures are not a promise of money.
const REAL_PAYOUTS_ENABLED = false;
const sessions = new Map(); // bearer token => session; volatile intentionally
const matches = new Map();
const waitingTokens = {2:[],4:[]}; // Separate genuine 2- and 4-player matchmaking queues.
const rateBuckets = new Map();

function loadDb(){
  try {
    const parsed=JSON.parse(fs.readFileSync(DATA_FILE,'utf8'));
    if (Array.isArray(parsed.results) && Array.isArray(parsed.requests)) {
      if (!Array.isArray(parsed.users)) parsed.users = [];
      if (!Array.isArray(parsed.authSessions)) parsed.authSessions = [];
      if (!Array.isArray(parsed.orders)) parsed.orders = [];
      if (!Array.isArray(parsed.withdrawals)) parsed.withdrawals = [];
      if (!Array.isArray(parsed.coinTransactions)) parsed.coinTransactions = [];
      return parsed;
    }
  } catch(_){}
  return {results:[],requests:[],users:[],authSessions:[],orders:[],withdrawals:[],coinTransactions:[]};
}
let db=loadDb();
function saveDb(){
  fs.mkdirSync(DATA_DIR,{recursive:true});
  const tmp=`${DATA_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmp,JSON.stringify(db,null,2),{mode:0o600});
  fs.renameSync(tmp,DATA_FILE);
}
const uid=()=>crypto.randomBytes(24).toString('base64url');
function coinBalance(userId){
  return db.coinTransactions.filter(x=>x.userId===userId).reduce((sum,x)=>sum+x.amount,0);
}
function coinHistory(userId){
  return db.coinTransactions.filter(x=>x.userId===userId).slice(-30).reverse().map(x=>({id:x.id,type:x.type,amount:x.amount,matchId:x.matchId,createdAt:x.createdAt}));
}
const now=()=>Date.now();
const normalized=s=>String(s||'').normalize('NFC').replace(/ي/g,'ی').replace(/ك/g,'ک').trim();
const cleanName=s=>normalized(s).replace(/[\u0000-\u001f<>]/g,'').slice(0,18);
// Iranian mobile numbers; accepts Persian/Arabic digits, 09..., 989..., +989... .
function normalizePhone(input){
  if(typeof input!=='string')return null;
  const digits=input.trim().replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-0x06f0))
    .replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-0x0660))
    .replace(/[\s\-]/g,'');
  const local = digits.startsWith('+98') ? '0'+digits.slice(3) :
    digits.startsWith('0098') ? '0'+digits.slice(4) :
    digits.startsWith('98') ? '0'+digits.slice(2) : digits;
  return /^09[0-9]{9}$/.test(local) ? local : null;
}
function passwordOk(password){return typeof password==='string' && Buffer.byteLength(password,'utf8')>=8 && Buffer.byteLength(password,'utf8')<=256;}
function authRateOk(req){
  const ip = req.socket.remoteAddress || 'unknown';
  const t=now();
  let b=authRateBuckets.get(ip);
  if(!b || t-b.start>60_000){b={start:t,count:0};authRateBuckets.set(ip,b);}
  return ++b.count<=12;
}
function hashPassword(password,salt){return crypto.scryptSync(password,salt,64,{N:16384,r:8,p:1}).toString('hex');}
const publicUser=u=>({id:u.id,phone:u.phone||null,name:u.name,avatar:u.avatar,photoUrl:u.photoKey ? `/profile-images/${u.photoKey}.jpg` : null,createdAt:u.createdAt,phoneVerified:false,onlineCoins:coinBalance(u.id)});
function getAuthUser(req){
  const bearer=req.headers.authorization||'';
  if(!bearer.startsWith('Bearer '))return null;
  const token=bearer.slice(7);
  if(!/^[a-zA-Z0-9_-]{30,128}$/.test(token))return null;
  const tokenHash=hash(token);
  const row=db.authSessions.find(s=>s.tokenHash===tokenHash && s.expiresAt>now());
  if(!row)return null;
  const user=db.users.find(u=>u.id===row.userId);
  return user?{user,tokenHash}:null;
}
function newAuthSession(user){
  const token=uid();
  db.authSessions=db.authSessions.filter(s=>s.expiresAt>now()).slice(-5000);
  db.authSessions.push({tokenHash:hash(token),userId:user.id,expiresAt:now()+SESSION_MS});
  saveDb();
  return token;
}
function profileStats(userId){
  const results=db.results.filter(r=>r.userId===userId);
  return {matches:results.length,wins:results.filter(r=>r.position==='winner').length,
    bestScore:results.reduce((best,r)=>Math.max(best,r.score||0),0)};
} 
const shuffled=arr=>{
  const out=arr.slice();
  for(let i=out.length-1;i>0;i--){const j=crypto.randomInt(i+1);[out[i],out[j]]=[out[j],out[i]];}
  return out;
};
const send=(res,code,data)=>{
  const body=JSON.stringify(data);
  res.writeHead(code,{
    'Content-Type':'application/json; charset=utf-8',
    'Content-Length':Buffer.byteLength(body),
    'Cache-Control':'no-store',
    'X-Content-Type-Options':'nosniff',
    'X-Frame-Options':'DENY',
    'Referrer-Policy':'no-referrer'
  });
  res.end(body);
};
const bad=(res,message,code=400)=>send(res,code,{error:message});
function rateOk(req){
  const ip=req.socket.remoteAddress || 'unknown';
  const t=now();
  let b=rateBuckets.get(ip);
  if(!b||t-b.start>10_000){b={start:t,count:0};rateBuckets.set(ip,b);}
  return ++b.count <= 250; // Rapid state polls for 2-second rounds across four clients/NAT.
}
function authenticate(req){
  const auth=req.headers.authorization||'';
  if(!auth.startsWith('Bearer ')) return null;
  const token=auth.slice(7);
  if(token.length>128)return null;
  const s=sessions.get(token);
  return s ? {token,session:s} : null;
}
function publicPlayer(p){return {name:p.name,score:Math.max(0,p.solved*100-p.mistakes*10),solved:p.solved,finished:p.finished,rank:p.rank||null};}
function finalizeMatch(match){
  if(match.finalized)return;
  match.finalized=true;
  const ordered=match.players.slice().sort((a,b)=>
    (b.solved*100-b.mistakes*10)-(a.solved*100-a.mistakes*10));
  const scheme=COIN_REWARDS[match.playerCount];
  for(const p of match.players){
    p.score=Math.max(0,p.solved*100-p.mistakes*10);
    p.rank=1+match.players.filter(q=>(q.solved*100-q.mistakes*10)>(p.solved*100-p.mistakes*10)).length;
    const tied=match.players.some(q=>q!==p && q.solved*100-q.mistakes*10===p.solved*100-p.mistakes*10);
    p.position=tied?'tie':p.rank===1?'winner':p.rank===2?'runnerUp':p.rank===3?'third':'fourth';
    p.rewardPreview=0;
    const proposed=tied?0:(scheme[p.rank-1]||0);
    const exists=db.coinTransactions.some(x=>x.matchId===match.id&&x.userId===p.userId&&x.type==='online_win');
    // A guest never receives stored rewards; the same account cannot fill multiple seats.
    p.coinsWon=proposed && p.userId && db.users.some(u=>u.id===p.userId) && !exists?proposed:0;
    if(p.coinsWon)db.coinTransactions.push({id:uid(),userId:p.userId,matchId:match.id,type:'online_win',amount:p.coinsWon,createdAt:new Date().toISOString()});
    db.results.push({id:uid(),matchId:match.id,userId:p.userId||null,name:p.name,score:p.score,solved:p.solved,position:p.position,rank:p.rank,mode:match.playerCount,coinsWon:p.coinsWon,finishedAt:new Date().toISOString()});
  }
  db.results=db.results.slice(-5000);
  saveDb();
}
function finishOne(match,p,timestamp){
  if(p.finished)return;
  p.finished=true;
  p.finishedAt=timestamp;
  p.score=Math.max(0,p.solved*100-p.mistakes*10);
}
function updateMatch(match){
  if(match.finalized)return;
  const t=now();
  for(const p of match.players){
    // Every photo lasts EXACTLY two seconds, starting from a single server clock.
    // A correct answer does not extend the timer or skip a question.
    if(p.finished)continue;
    const elapsed=Math.max(0,t-match.created);
    const next=Math.min(QUESTION_COUNT,Math.floor(elapsed/QUESTION_TIME_MS));
    p.questionIndex=next;
    p.questionDeadline=match.created+(next+1)*QUESTION_TIME_MS;
    if(next>=QUESTION_COUNT)finishOne(match,p,match.deadline);
  }
  if(match.players.every(p=>p.finished))finalizeMatch(match);
}
function stateOf(token){
  const sess=sessions.get(token);
  if(!sess)return null;
  if(!sess.matchId){
    const queue=waitingTokens[sess.playerCount]||[];
    return {status:'waiting',name:sess.name,playerCount:sess.playerCount,waitingCount:queue.filter(t=>sessions.has(t)&&!sessions.get(t).matchId).length,needed:sess.playerCount};
  }
  const match=matches.get(sess.matchId);
  if(!match)return {status:'expired',name:sess.name};
  updateMatch(match);
  const me=match.players.find(p=>p.token===token);
  if(!me)return {status:'expired',name:sess.name};
  const others=match.players.filter(p=>p.token!==token);
  const common={matchId:match.id,my:publicPlayer(me),other:publicPlayer(others[0]),players:match.players.map(publicPlayer),playerCount:match.playerCount,
    questionSeconds:QUESTION_SECONDS,totalQuestions:QUESTION_COUNT,totalSeconds:QUESTION_SECONDS*QUESTION_COUNT,
    prizes:COIN_REWARDS[match.playerCount],payoutStatus:'disabled',entryFeeCoins:0,coinRewardPerWin:COIN_REWARDS[match.playerCount][0]};
  if(match.finalized)return {
    ...common,status:'finished',position:me.position,rank:me.rank,rewardPreview:0,coinsWon:me.coinsWon||0,
    coinBalance:me.userId?coinBalance(me.userId):null,
    canRequestReview:false,reviewRequested:false
  };
  return {...common,status:me.finished?'waiting_opponent':'active',
    secondsLeft:me.finished?0:Math.max(0,Math.ceil((me.questionDeadline-now())/1000)),
    questionIndex:me.questionIndex,answeredCurrent:me.answeredIndex===me.questionIndex,
    stageIndex:me.finished?null:match.questions[me.questionIndex]};
}
function hash(str){return crypto.createHash('sha256').update(str).digest('hex');}
function startMatch(tokens){
  const t=now();
  const id=uid();
  const match={id,created:t,deadline:t+QUESTION_COUNT*QUESTION_TIME_MS,finalized:false,playerCount:tokens.length,
    questions:shuffled(ANSWERS.map((_,i)=>i)).slice(0,QUESTION_COUNT),
    players:tokens.map(token=>({token,name:sessions.get(token).name,userId:sessions.get(token).userId||null,
      questionIndex:0,questionDeadline:t+QUESTION_TIME_MS,answeredIndex:-1,solved:0,mistakes:0,score:0,finished:false}))};
  matches.set(id,match);
  for(const token of tokens)sessions.get(token).matchId=id;
}
function leaderboard(){
  const list=db.results.slice().sort((a,b)=>b.score-a.score || (a.finishedAt<b.finishedAt?-1:1)).slice(0,20);
  return list.map((p,i)=>({rank:i+1,name:p.name,score:p.score,solved:p.solved,date:p.finishedAt}));
}
function parseJson(req){
  return new Promise((resolve,reject)=>{
    let chunks=[],len=0,ended=false;
    req.on('data',chunk=>{
      if(ended)return;
      len+=chunk.length;
      if(len>2048){ended=true;reject(new Error('too_large'));req.destroy();return;}
      chunks.push(chunk);
    });
    req.on('end',()=>{if(ended)return; try {resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}'));} catch(_){reject(new Error('invalid_json'));}});
    req.on('error',reject);
  });
}

function parseImageBody(req,maxBytes=250000){
  return new Promise((resolve,reject)=>{
    const contentLength=Number(req.headers['content-length']||0);
    if(contentLength>maxBytes)return reject(new Error('too_large'));
    let length=0,done=false;
    const parts=[];
    req.on('data',chunk=>{
      if(done)return;
      length+=chunk.length;
      if(length>maxBytes){done=true;req.destroy();reject(new Error('too_large'));return;}
      parts.push(chunk);
    });
    req.on('end',()=>{
      if(done)return;
      const buf=Buffer.concat(parts);
      // This endpoint intentionally handles only canvas-generated JPEGs.
      if(buf.length<200||buf[0]!==0xff||buf[1]!==0xd8||buf[2]!==0xff ||
         buf[buf.length-2]!==0xff || buf[buf.length-1]!==0xd9){
        reject(new Error('invalid_image'));return;
      }
      resolve(buf);
    });
    req.on('error',reject);
  });
}
function serveMusic(req,res){
  let stats;
  try{stats=fs.statSync(MUSIC_FILE);}catch(_){return bad(res,'موسیقی پیدا نشد.',404);}
  const total=stats.size;
  const range=req.headers.range;
  let start=0,end=total-1,status=200;
  if(range){
    const match=/^bytes=(\d+)-(\d*)$/.exec(range);
    if(!match)return res.writeHead(416,{'Content-Range':`bytes */${total}`}).end();
    start=Number(match[1]);
    end=match[2]?Number(match[2]):total-1;
    if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start>end||start>=total)
      return res.writeHead(416,{'Content-Range':`bytes */${total}`}).end();
    end=Math.min(end,total-1);
    status=206;
  }
  const headers={
    'Content-Type':'audio/mpeg','X-Content-Type-Options':'nosniff','Accept-Ranges':'bytes',
    'Content-Length':end-start+1,'Cache-Control':'public,max-age=86400'
  };
  if(status===206)headers['Content-Range']=`bytes ${start}-${end}/${total}`;
  res.writeHead(status,headers);
  fs.createReadStream(MUSIC_FILE,{start,end}).pipe(res);
}
async function route(req,res){
  if(!rateOk(req))return bad(res,'درخواست بیش‌ازحد؛ کمی بعد تلاش کنید.',429);
  let pathname;
  try{pathname=new URL(req.url,'http://localhost').pathname;}catch(_){return bad(res,'نشانی نامعتبر',400);}
  if(req.method==='GET' && (pathname==='/'||pathname==='/index.html')){
    // Mark only pages served by the actual Node backend as connected; standalone previews
    // remain fully interactive LOCAL DEMOS without inventing remote accounts or opponents.
    const html=Buffer.from(fs.readFileSync(HTML_FILE,'utf8').replace(
      '<html lang="fa" dir="rtl">',
      '<html lang="fa" dir="rtl" data-server-backend="true">'), 'utf8');
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Length':html.length,
      'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Cache-Control':'no-cache', 'Referrer-Policy':'no-referrer'});
    return res.end(html);
  }
  if(req.method==='GET' && pathname==='/music/blue-garden.mp3')return serveMusic(req,res);
  // Foto puzzles are packaged offline and served as immutable same-origin files online.
  if(req.method==='GET' && /^\/photos\/[a-z0-9_-]+\.jpg$/.test(pathname)){
    const file=path.join(__dirname,'..',pathname.slice(1));
    let photo;
    try{photo=fs.readFileSync(file);}catch(_){return bad(res,'تصویر پیدا نشد.',404);}
    res.writeHead(200,{'Content-Type':'image/jpeg','Content-Length':photo.length,
      'Cache-Control':'public,max-age=86400','X-Content-Type-Options':'nosniff'});
    return res.end(photo);
  }

  if(req.method==='GET' && /^\/profile-images\/[a-f0-9]{40}\.jpg$/.test(pathname)){
    const key=pathname.split('/')[2].slice(0,-4);
    // Public opaque image URL for avatars, never exposing arbitrary disk paths.
    if(!db.users.some(u=>u.photoKey===key))return bad(res,'تصویر پیدا نشد.',404);
    let img;
    try{img=fs.readFileSync(path.join(PROFILE_PHOTO_DIR,`${key}.jpg`));}
    catch(_){return bad(res,'تصویر پیدا نشد.',404);}
    res.writeHead(200,{'Content-Type':'image/jpeg','Content-Length':img.length,
      'Cache-Control':'public,max-age=86400,immutable','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY'});
    return res.end(img);
  }
  if(req.method==='GET' && pathname==='/api/config')return send(res,200,{
    onlineAvailable:true,payoutsEnabled:REAL_PAYOUTS_ENABLED, paymentsEnabled:PAYMENTS_ENABLED,withdrawalsEnabled:WITHDRAWALS_ENABLED,
    entryFeeCoins:0,coinRewardPerWin:WIN_COINS,coinRewardsByMode:COIN_REWARDS,conversionEnabled:false,rateIsIndicative:false,billingProvider:BILLING_PROVIDER,billingSetupRequired:BILLING_SETUP_REQUIRED,tomanPerCoin:NOMINAL_TOMAN_PER_COIN,rialsPerCoin:NOMINAL_RIALS_PER_COIN,
    prizePreview:{winner:PRIZES.winner,runnerUp:PRIZES.runnerUp,tie:PRIZES.tie},
    durationSeconds:QUESTION_SECONDS*QUESTION_COUNT,questionSeconds:QUESTION_SECONDS,questions:QUESTION_COUNT,playerCounts:[2,4],
    notice:'۲۰ تصویر، هر تصویر ۲ ثانیه، مجموعاً ۴۰ ثانیه. دونفره: نفر اول ۳۰ سکه. چهارنفره: نفر اول ۵۰ و نفر دوم ۳۰ سکه. در تساوی جایزه‌ای داده نمی‌شود. سکه‌ها مجازی و غیرقابل برداشت‌اند.'
  });
  // Shop and wallet are honest, non-transactional staging endpoints.
  // No payment token, PAN, card or IBAN is accepted or stored.
  if(req.method==='GET' && pathname==='/api/shop/catalog')return send(res,200,{
    products:SHOP_PACKS,paymentsEnabled:PAYMENTS_ENABLED,billingProvider:BILLING_PROVIDER,billingSetupRequired:BILLING_SETUP_REQUIRED,conversionEnabled:false,rateIsIndicative:false,tomanPerCoin:NOMINAL_TOMAN_PER_COIN,rialsPerCoin:NOMINAL_RIALS_PER_COIN,
    message:'قیمت بستهٔ ۱۰۰ سکه، ۳٬۵۰۰ تومان است. درگاه مایکت هنوز راه‌اندازی نشده؛ هیچ پرداختی دریافت یا سکه‌ای خریداری نمی‌شود.'
  });
  if(pathname==='/api/wallet'||pathname==='/api/shop/orders'||pathname==='/api/wallet/withdrawals'||pathname==='/api/wallet/convert'){
    const account=getAuthUser(req);
    if(!account)return bad(res,'برای استفاده از کیف پول باید وارد حساب شوید.',401);
    const userId=account.user.id;
    if(req.method==='GET' && pathname==='/api/wallet'){
      const myOrders=db.orders.filter(o=>o.userId===userId).slice(-15).reverse();
      return send(res,200,{
        purchasedCoins:0,earnedCoins:coinBalance(userId),onlineCoins:coinBalance(userId),
        coinTransactions:coinHistory(userId),rialsPerCoin:NOMINAL_RIALS_PER_COIN,tomanPerCoin:NOMINAL_TOMAN_PER_COIN,rateIsIndicative:false,conversionEnabled:false,billingProvider:BILLING_PROVIDER,billingSetupRequired:BILLING_SETUP_REQUIRED,
        verifiedCashToman:0,withdrawableToman:0,
        paymentsEnabled:PAYMENTS_ENABLED,withdrawalsEnabled:WITHDRAWALS_ENABLED,
        orders:myOrders.map(({id,productId,coins,priceToman,status,createdAt})=>({id,productId,coins,priceToman,status,createdAt})),
        notice:'هر ۱۰۰ سکه در فروشگاه ۳٬۵۰۰ تومان قیمت‌گذاری شده، اما خرید هنوز فعال نشده است. سکه‌ها معادل پول یا اعتبار قابل برداشت نیستند.'
      });
    }
    if(req.method==='POST' && pathname==='/api/shop/orders'){
      // A future production endpoint must first create an order, launch the store SDK,
      // and verify purchase tokens against Myket from the server, with a durable unique
      // receipt ledger. Never accept a client's 'paid' flag or self-supplied coins.
      return bad(res,'خرید واقعی پس از ثبت برنامه در پنل توسعه‌دهندگان مایکت و اتصال تأیید امن پرداخت فعال می‌شود. فعلاً وجهی دریافت یا سکه‌ای افزوده نمی‌شود.',503);
    }
    if(req.method==='POST' && pathname==='/api/wallet/convert'){
      return bad(res,'قیمت فروشگاه ۳٬۵۰۰ تومان برای هر ۱۰۰ سکه است؛ این قیمت حق تبدیل سکه به وجه نقد ایجاد نمی‌کند. برداشت بانکی غیرفعال است.',403);
    }
    if(req.method==='POST' && pathname==='/api/wallet/withdrawals'){
      return bad(res,'برداشت فعلاً غیرفعال است؛ موجودی نقدی تأییدشده صفر است. لطفاً اطلاعات بانکی وارد نکنید.',403);
    }
    return bad(res,'مسیر پیدا نشد.',404);
  }
  // Account registration and profile: accounts need this server, offline HTML remains playable as guest.
  if(req.method==='POST' && (pathname==='/api/account/register'||pathname==='/api/account/login')){
    if(!authRateOk(req))return bad(res,'تلاش‌های متعدد؛ یک دقیقه بعد دوباره تلاش کنید.',429);
    let body;
    try{body=await parseJson(req);}catch(_){return bad(res,'درخواست معتبر نیست.');}
    if(!body || typeof body.phone!=='string'||typeof body.password!=='string')return bad(res,'شماره موبایل و رمز عبور الزامی است.');
    const phone=normalizePhone(body.phone);
    if(!phone)return bad(res,'شماره موبایل ایران را با قالب ۰۹xxxxxxxxx وارد کنید.');
    if(pathname==='/api/account/register'){
      const name=typeof body.name==='string'?cleanName(body.name):'';
      if(name.length<2)return bad(res,'نام نمایشی باید حداقل ۲ نویسه داشته باشد.');
      if(!passwordOk(body.password))return bad(res,'رمز باید حداقل ۸ نویسه و حداکثر ۲۵۶ بایت باشد.');
      if(db.users.some(u=>u.phone===phone))return bad(res,'این شماره قبلاً ثبت شده است.',409);
      const salt=crypto.randomBytes(16).toString('hex');
      const user={id:uid(),phone,name,avatar:AVATARS[0],salt,passwordHash:hashPassword(body.password,salt),createdAt:new Date().toISOString()};
      db.users.push(user);
      const token=newAuthSession(user);
      return send(res,201,{token,user:publicUser(user),stats:profileStats(user.id)});
    }
    const user=db.users.find(u=>u.phone===phone);
    // Equal work on missing accounts, no plaintext password is saved.
    const reference=user||{salt:'00000000000000000000000000000000',passwordHash:'0'.repeat(128)};
    const candidate=Buffer.from(hashPassword(body.password,reference.salt),'hex');
    const actual=Buffer.from(reference.passwordHash,'hex');
    if(!user||!crypto.timingSafeEqual(candidate,actual))return bad(res,'شماره موبایل یا رمز عبور اشتباه است.',401);
    return send(res,200,{token:newAuthSession(user),user:publicUser(user),stats:profileStats(user.id)});
  }
  if(pathname.startsWith('/api/account/')){
    const auth=getAuthUser(req);
    if(!auth)return bad(res,'برای مشاهدهٔ حساب وارد شوید.',401);
    if(req.method==='GET' && pathname==='/api/account/me'){
      return send(res,200,{user:publicUser(auth.user),stats:profileStats(auth.user.id)});
    }
    if(req.method==='PATCH' && pathname==='/api/account/profile'){
      let body;
      try{body=await parseJson(req);}catch(_){return bad(res,'اطلاعات معتبر نیست.');}
      if(!body||typeof body.name!=='string'||typeof body.avatar!=='string')return bad(res,'اطلاعات پروفایل ناقص است.');
      const name=cleanName(body.name);
      if(name.length<2)return bad(res,'نام نمایشی باید حداقل ۲ نویسه باشد.');
      if(!AVATARS.includes(body.avatar))return bad(res,'آواتار انتخاب‌شده معتبر نیست.');
      auth.user.name=name;
      auth.user.avatar=body.avatar;
      saveDb();
      return send(res,200,{user:publicUser(auth.user),stats:profileStats(auth.user.id)});
    }
    if(req.method==='POST' && pathname==='/api/account/photo'){
      if(req.headers['content-type']?.split(';')[0] !== 'image/jpeg')return bad(res,'عکس باید JPG باشد.',415);
      let jpeg;
      try{jpeg=await parseImageBody(req);}catch(_){return bad(res,'عکس نامعتبر است یا بیش از ۲۵۰ کیلوبایت حجم دارد.');}
      fs.mkdirSync(PROFILE_PHOTO_DIR,{recursive:true,mode:0o700});
      const key=crypto.randomBytes(20).toString('hex');
      fs.writeFileSync(path.join(PROFILE_PHOTO_DIR,`${key}.jpg`),jpeg,{mode:0o600,flag:'wx'});
      const previous=auth.user.photoKey;
      auth.user.photoKey=key;
      try{saveDb();}catch(err){auth.user.photoKey=previous;fs.rmSync(path.join(PROFILE_PHOTO_DIR,`${key}.jpg`),{force:true});throw err;}
      if(previous && /^[a-f0-9]{40}$/.test(previous))fs.rmSync(path.join(PROFILE_PHOTO_DIR,`${previous}.jpg`),{force:true});
      return send(res,200,{user:publicUser(auth.user),stats:profileStats(auth.user.id)});
    }
    if(req.method==='DELETE' && pathname==='/api/account/photo'){
      const previous=auth.user.photoKey;
      delete auth.user.photoKey;
      saveDb();
      if(previous && /^[a-f0-9]{40}$/.test(previous))fs.rmSync(path.join(PROFILE_PHOTO_DIR,`${previous}.jpg`),{force:true});
      return send(res,200,{user:publicUser(auth.user),stats:profileStats(auth.user.id)});
    }
    if(req.method==='POST' && pathname==='/api/account/logout'){
      db.authSessions=db.authSessions.filter(s=>s.tokenHash!==auth.tokenHash);
      saveDb();
      return send(res,200,{loggedOut:true});
    }
    return bad(res,'مسیر پیدا نشد.',404);
  }
  if(req.method==='GET' && pathname==='/api/online/leaderboard')return send(res,200,{rows:leaderboard()});
  if(req.method==='POST' && pathname==='/api/online/join'){
    let body;
    try{body=await parseJson(req);}catch(_){return bad(res,'درخواست معتبر نیست.');}
    if(!body||typeof body.name!=='string')return bad(res,'نام بازیکن را وارد کنید.');
    const playerCount=body.playerCount===4?4:2;
    const accountAuth=getAuthUser(req);
    if(req.headers.authorization && !accountAuth)return bad(res,'نشست حساب نامعتبر است؛ دوباره وارد شوید.',401);
    const name=accountAuth?accountAuth.user.name:cleanName(body.name);
    if(name.length<2||name.length>18)return bad(res,'نام باید بین ۲ تا ۱۸ نویسه باشد.');
    // Protect reward ledger: no simultaneous seats for the same logged-in account.
    if(accountAuth && [...sessions.values()].some(s=>s.userId===accountAuth.user.id &&
      (!s.matchId || (matches.has(s.matchId) && !matches.get(s.matchId).finalized))))
      return bad(res,'این حساب هم‌اکنون در صف یا مسابقه دیگری است.',409);
    const token=uid();
    sessions.set(token,{name,userId:accountAuth?.user.id||null,matchId:null,playerCount,created:now()});
    const queue=waitingTokens[playerCount];
    for(let i=queue.length-1;i>=0;i--)if(!sessions.has(queue[i]) || sessions.get(queue[i]).matchId)queue.splice(i,1);
    queue.push(token);
    if(queue.length>=playerCount)startMatch(queue.splice(0,playerCount));
    return send(res,200,{token,state:stateOf(token)});
  }
  const auth=authenticate(req);
  if(!auth)return bad(res,'نشست معتبر نیست؛ دوباره وارد مسابقه شوید.',401);
  const {token,session}=auth;
  if(req.method==='GET' && pathname==='/api/online/state')return send(res,200,stateOf(token));
  if(req.method==='POST' && pathname==='/api/online/answer'){
    let body;
    try{body=await parseJson(req);}catch(_){return bad(res,'فرمت پاسخ نادرست است.');}
    const match=matches.get(session.matchId);
    if(!match)return bad(res,'مسابقه پیدا نشد.',404);
    updateMatch(match);
    const me=match.players.find(p=>p.token===token);
    if(match.finalized || me.finished)return bad(res,'زمان یا مسابقه پایان یافته است.',409);
    if(typeof body.answer !== 'string' || body.answer.length>30)return bad(res,'پاسخ نامعتبر است.');
    if(Number.isInteger(body.questionIndex) && body.questionIndex!==me.questionIndex)
      return send(res,200,{correct:false,expired:true,state:stateOf(token)});
    const t=now();
    if(me.answeredIndex===me.questionIndex)
      return send(res,200,{correct:false,alreadyAnswered:true,state:stateOf(token)});
    if(me.lastAttempt && t-me.lastAttempt<150)return bad(res,'پاسخ‌ها را با فاصله ارسال کنید.',429);
    me.lastAttempt=t;
    const expected=ANSWERS[match.questions[me.questionIndex]];
    const correct=normalized(body.answer)===expected;
    if(correct){
      me.solved++;
      me.answeredIndex=me.questionIndex;
    }else{
      me.mistakes++;
    }
    updateMatch(match);
    return send(res,200,{correct,state:stateOf(token)});
  }
  if(req.method==='POST' && pathname==='/api/online/leave'){
    for(const queue of Object.values(waitingTokens)){const idx=queue.indexOf(token);if(idx>=0)queue.splice(idx,1);}
    if(session.matchId){
      const match=matches.get(session.matchId);
      if(match){
        const me=match.players.find(p=>p.token===token);
        if(me&&!me.finished){
          me.solved=0;
          me.mistakes=0;
          finishOne(match,me,now());
          me.score=0;
          updateMatch(match);
        }
      }
    }
    sessions.delete(token);
    return send(res,200,{left:true});
  }
  if(req.method==='POST' && pathname==='/api/online/review-request')return bad(res,'در این نسخه جایزه نقدی و درخواست برداشت فعال نیست؛ جایزه فقط سکه مجازی است.',403);
  if(false && req.method==='POST' && pathname==='/api/online/review-request'){
    const match=matches.get(session.matchId);
    if(!match)return bad(res,'مسابقه پیدا نشد.',404);
    updateMatch(match);
    if(!match.finalized)return bad(res,'مسابقه هنوز تمام نشده است.');
    const me=match.players.find(p=>p.token===token);
    if(me.rewardPreview<=0)return bad(res,'شرایط ثبت درخواست را نداری.');
    const tokenHash=hash(token);
    if(db.requests.some(r=>r.matchId===match.id&&r.tokenHash===tokenHash))return send(res,200,{status:'pending_review',payoutStatus:'disabled'});
    db.requests.push({id:uid(),matchId:match.id,tokenHash,name:me.name,previewAmount:me.rewardPreview,status:'pending_review',requestedAt:new Date().toISOString()});
    saveDb();
    return send(res,200,{status:'pending_review',payoutStatus:'disabled',message:'صرفاً درخواست بررسی ثبت شد؛ این درخواست حق دریافت پول یا پرداخت ایجاد نمی‌کند.'});
  }
  return bad(res,'مسیر پیدا نشد.',404);
}
const server=http.createServer((req,res)=>{route(req,res).catch(err=>{
  console.error(err);
  if(!res.headersSent)bad(res,'خطای داخلی سرور',500); else res.end();
});});
const cleanup=setInterval(()=>{
  const t=now();
  for(const [id,m] of matches){updateMatch(m); if(m.finalized&&t-m.deadline>20*60_000)matches.delete(id);}
  for(const [token,s] of sessions)if(t-s.created>45*60_000){for(const queue of Object.values(waitingTokens)){const i=queue.indexOf(token);if(i>=0)queue.splice(i,1);}sessions.delete(token);}
  for(const [ip,b] of rateBuckets)if(t-b.start>15_000)rateBuckets.delete(ip);
  for(const [ip,b] of authRateBuckets)if(t-b.start>60_000)authRateBuckets.delete(ip);
  const prior=db.authSessions.length;
  db.authSessions=db.authSessions.filter(s=>s.expiresAt>t);
  if(prior!==db.authSessions.length)saveDb();
},15_000);
cleanup.unref();
if(require.main===module){server.listen(PORT,HOST,()=>console.log(`Vazhehchin server: http://${HOST}:${PORT} (real payouts disabled)`));}
module.exports={server};
