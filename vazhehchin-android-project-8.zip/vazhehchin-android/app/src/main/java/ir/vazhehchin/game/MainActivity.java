package ir.vazhehchin.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;

import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.HashMap;

/**
 * Android shell for the Persian puzzle and competition game.
 * Loads a configured HTTPS origin for online play, otherwise bundled offline HTML.
 * Never allows insecure HTTP or arbitrary third-party navigation.
 * The secure appassets origin allows localStorage in offline mode.
 */
public final class MainActivity extends Activity {
    private static final String SITE_HOST = "appassets.androidplatform.net";
    private static final String HOME_URL = "https://appassets.androidplatform.net/assets/index.html";
    private WebView webView;
    private LinearLayout connectionPanel;
    private TextView connectionText;
    private static final int PHOTO_PICKER_REQUEST = 621;
    private ValueCallback<Uri[]> photoPickerCallback;
    private String onlineOrigin;
    private String homeUrl;
    private boolean connectionFailed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setNavigationBarColor(Color.rgb(236, 245, 255));
        getWindow().setStatusBarColor(Color.rgb(236, 245, 255));

        // Only a production HTTPS origin can enable network matches.
        String config = BuildConfig.GAME_SERVER_URL.trim();
        Uri configured = Uri.parse(config);
        if ("https".equals(configured.getScheme()) && configured.getHost() != null
               ) {
            onlineOrigin = "https://" + configured.getAuthority();
            homeUrl = onlineOrigin + "/";
        } else {
            onlineOrigin = null;
            homeUrl = HOME_URL;
        }
        FrameLayout container = new FrameLayout(this);
        container.setBackgroundColor(Color.rgb(236, 245, 255));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(236, 245, 255));
        container.addView(webView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));

        // An unavailable HTTPS server must NOT silently look like online play.
        // Offer a retry (for example, after enabling a system-wide VPN) and an
        // explicitly labelled offline story option instead of faking opponents.
        if (onlineOrigin != null) {
            connectionPanel = new LinearLayout(this);
            connectionPanel.setOrientation(LinearLayout.VERTICAL);
            connectionPanel.setGravity(Gravity.CENTER);
            connectionPanel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            connectionPanel.setPadding(dp(25),dp(30),dp(25),dp(30));
            connectionPanel.setBackgroundColor(Color.rgb(240,246,255));
            connectionText = new TextView(this);
            connectionText.setTextColor(Color.rgb(26,54,92));
            connectionText.setTextSize(18);
            connectionText.setGravity(Gravity.CENTER);
            connectionText.setText("اتصال به سرور مسابقه برقرار نشد. اینترنت و VPN گوشی را بررسی کن.");
            connectionPanel.addView(connectionText, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));

            Button retry = new Button(this);
            retry.setText("🌐 تلاش دوباره برای اتصال آنلاین");
            LinearLayout.LayoutParams retryParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            retryParams.topMargin = dp(18);
            connectionPanel.addView(retry,retryParams);
            retry.setOnClickListener(v -> {
                showConnectingPanel();
                webView.loadUrl(onlineOrigin + "/");
            });

            Button offline = new Button(this);
            offline.setText("🧩 فقط حدس تصویر آفلاین (بدون بازیکن واقعی)");
            connectionPanel.addView(offline,new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
            offline.setOnClickListener(v -> {
                hideConnectionPanel();
                webView.loadUrl(HOME_URL + "?appMode=offline");
            });

            FrameLayout.LayoutParams box = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,FrameLayout.LayoutParams.MATCH_PARENT);
            container.addView(connectionPanel,box);
            connectionPanel.setVisibility(View.GONE);
        }

        // Android 15 edge-to-edge: keep game away from status/navigation buttons.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                         | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(mask, mask);
            }
            container.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets safe = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return insets;
            });
        }
        setContentView(container);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        // Play the game's self-generated soundtrack on entry in Android WebView.
        // Mobile browsers may still need one user gesture because of autoplay rules.
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        // Content picker access is required for a user-selected profile picture.
        // Arbitrary local file access remains disabled.
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new OfflineGameClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params){
                if(photoPickerCallback != null) photoPickerCallback.onReceiveValue(null);
                photoPickerCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                try{
                    startActivityForResult(Intent.createChooser(intent,"انتخاب عکس پروفایل"),PHOTO_PICKER_REQUEST);
                    return true;
                }catch(ActivityNotFoundException ex){
                    photoPickerCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });
        if (onlineOrigin != null) showConnectingPanel();
        webView.loadUrl(homeUrl);
    }

    private int dp(int count) {
        return Math.round(count * getResources().getDisplayMetrics().density);
    }

    private void hideConnectionPanel() {
        if(connectionPanel!=null)connectionPanel.setVisibility(View.GONE);
        if(webView!=null)webView.setVisibility(View.VISIBLE);
    }

    private void showConnectingPanel() {
        if (onlineOrigin == null || connectionPanel == null || webView == null) return;
        connectionFailed = false;
        connectionText.setText("📱 واژه‌چین ۱.۹.۰\n⏳ در حال اتصال به سرور واژه‌چین...\n"
            + "این نسخه برای مسابقه با بازیکن واقعی به اینترنت نیاز دارد.\n"
            + "در سرور رایگان ممکن است اتصال اولیه نزدیک به یک دقیقه طول بکشد.");
        webView.setVisibility(View.INVISIBLE);
        connectionPanel.setVisibility(View.VISIBLE);
    }

    private void showConnectionPanel(String error) {
        if(onlineOrigin==null || connectionPanel==null || webView==null)return;
        connectionFailed = true;
        connectionText.setText("📱 واژه‌چین ۱.۹.۰\n🔴 اتصال آنلاین برقرار نشد؛ مسابقه با کامپیوتر شروع نمی‌شود.\n"
            + "اینترنت و VPN گوشی را بررسی کن و روی «تلاش دوباره» بزن.\n\n"
            + error);
        webView.setVisibility(View.INVISIBLE);
        connectionPanel.setVisibility(View.VISIBLE);
    }

    private boolean isOnlineUrl(Uri uri) {
        return onlineOrigin != null && uri != null
            && "https".equals(uri.getScheme())
            && Uri.parse(onlineOrigin).getAuthority().equals(uri.getAuthority());
    }

    private final class OfflineGameClient extends WebViewClient {
        @Override
        public void onPageStarted(WebView view,String url,android.graphics.Bitmap favicon) {
            if(url != null && isOnlineUrl(Uri.parse(url))) showConnectingPanel();
            else if (url!=null && url.startsWith(HOME_URL)) hideConnectionPanel();
        }

        @Override
        public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error) {
            if(request.isForMainFrame() && isOnlineUrl(request.getUrl())) {
                showConnectionPanel("پاسخی از سرور دریافت نشد (خطای شبکه: "
                    +error.getErrorCode()+").");
            }
        }

        @Override
        public void onReceivedHttpError(WebView view,WebResourceRequest request,
                                        WebResourceResponse response) {
            if(request.isForMainFrame() && isOnlineUrl(request.getUrl()) && response.getStatusCode()>=400)
                showConnectionPanel("سرور پاسخ ناموفق داد: "+response.getStatusCode());
        }

        @Override
        public void onPageFinished(WebView view,String url) {
            if(url != null && isOnlineUrl(Uri.parse(url)) && !connectionFailed) {
                // A remote error page is not a valid multiplayer game: verify the
                // server-only marker before declaring that real matches are enabled.
                view.evaluateJavascript(
                    "document.documentElement.dataset.serverBackend==='true' && !!document.getElementById('joinOnlineBtn')",result->{
                        if(webView==null || connectionFailed)return;
                        if(!"true".equals(result)) {
                            showConnectionPanel("صفحه سرور مسابقهٔ واقعی را تأیید نکرده است.");
                        } else {
                            hideConnectionPanel();
                            // The badge remains visible; do not imply a computer opponent.
                            view.evaluateJavascript(
                                "(function(){if(document.getElementById('apk-online-state'))return;"
                              + "var e=document.createElement('div');e.id='apk-online-state';"
                              + "e.textContent='🟢 نسخه ۱.۹.۰ • سرور متصل است • مسابقه با بازیکن واقعی';"
                              + "e.setAttribute('role','status');"
                              + "e.style.cssText='margin:-5px 0 11px;background:#e3f8e9;color:#145d33;"
                              + "border:1px solid #8ccaa1;border-radius:13px;padding:9px;"
                              + "text-align:center;font:bold 12px Tahoma,sans-serif';"
                              + "var h=document.querySelector('.topbar');"
                              + "if(h)h.insertAdjacentElement('afterend',e);"
                              + "else document.body.prepend(e)})()",null);
                        }
                    });
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            // No outgoing links or remote navigations: the game is self-contained.
            Uri uri = request.getUrl();
            // Online HTTPS origin and the explicit bundled offline page are allowed.
            if (isOnlineUrl(uri)) return false;
            if ("https".equals(uri.getScheme()) && SITE_HOST.equals(uri.getHost())
                    && "/assets/index.html".equals(uri.getPath()))return false;
            return true;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if ("https".equals(uri.getScheme())
                && SITE_HOST.equals(uri.getHost())
                && "/assets/index.html".equals(uri.getPath())) {
                try {
                    InputStream html = getAssets().open("index.html");
                    return new WebResourceResponse("text/html", "UTF-8", html);
                } catch (IOException ignored) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                        new ByteArrayInputStream("Game content missing".getBytes()));
                }
            }
            // Bundle actual photo puzzles locally; never fetch or expose arbitrary asset paths.
            if("https".equals(uri.getScheme()) && SITE_HOST.equals(uri.getHost())
                && uri.getPath() != null && uri.getPath().matches("/assets/photos/[a-zA-Z0-9_-]+\\.jpg")) {
                String assetPath = uri.getPath().substring("/assets/".length());
                try {
                    InputStream photo = getAssets().open(assetPath);
                    return new WebResourceResponse("image/jpeg", null, photo);
                } catch (IOException ignored) {
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                }
            }
            if("https".equals(uri.getScheme()) && SITE_HOST.equals(uri.getHost())
                && "/assets/music/blue-garden.mp3".equals(uri.getPath())) {
                try {
                    String assetPath = "music/blue-garden.mp3";
                    InputStream audio=getAssets().open(assetPath);
                    long total=audio.available();
                    if(total<=0){audio.close();throw new IOException("invalid size");}
                    long start=0,end=total-1;
                    boolean partial=false;
                    String range=request.getRequestHeaders().get("Range");
                    if(range != null && range.matches("bytes=\\d+-\\d*")) {
                        String[] numbers=range.substring(6).split("-",-1);
                        start=Long.parseLong(numbers[0]);
                        if(!numbers[1].isEmpty())end=Long.parseLong(numbers[1]);
                        end=Math.min(end,total-1);
                        if(start > end || start>=total)throw new IOException("range outside asset");
                        partial=true;
                    }
                    long skip=start;
                    while(skip>0){
                        long advanced=audio.skip(skip);
                        if(advanced<=0){audio.close();throw new IOException("seek failed");}
                        skip-=advanced;
                    }
                    Map<String,String> headers=new HashMap<>();
                    headers.put("Accept-Ranges","bytes");
                    headers.put("Content-Length",Long.toString(end-start+1));
                    if(partial)headers.put("Content-Range","bytes "+start+"-"+end+"/"+total);
                    final long remainingBytes = end-start+1;
                    return new WebResourceResponse("audio/mpeg",null,
                        partial?206:200,partial?"Partial Content":"OK",headers,
                        new java.io.FilterInputStream(audio){
                            long remaining=remainingBytes;
                            @Override public int read() throws IOException {
                                if(remaining<=0)return -1;
                                int v=super.read();if(v>=0)remaining--;return v;
                            }
                            @Override public int read(byte[] b,int off,int len) throws IOException {
                                if(remaining<=0)return -1;
                                int n=super.read(b,off,(int)Math.min(len,remaining));
                                if(n>0)remaining-=n;
                                return n;
                            }
                        });
                }catch(Exception ignored){
                    return new WebResourceResponse("text/plain","UTF-8",
                        new ByteArrayInputStream(new byte[0]));
                }
            }
            if(onlineOrigin != null && "https".equals(uri.getScheme())
                    && Uri.parse(onlineOrigin).getAuthority().equals(uri.getAuthority())) {
                // The deployed server may serve HTML, JS, and same-origin API routes.
                return null;
            }
            // Third-party requests and unknown local paths are blocked.
            return new WebResourceResponse("text/plain", "UTF-8",
                new ByteArrayInputStream(new byte[0]));
        }
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PHOTO_PICKER_REQUEST && photoPickerCallback!=null){
            Uri[] selection=null;
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                selection=new Uri[]{data.getData()};
            }
            photoPickerCallback.onReceiveValue(selection);
            photoPickerCallback=null;
        }
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
            .setTitle("خروج از واژه‌چین")
            .setMessage("می‌خواهی از بازی خارج شوی؟ پیشرفتت ذخیره شده است.")
            .setPositiveButton("خروج", (dialog, which) -> finish())
            .setNegativeButton("ادامهٔ بازی", (dialog, which) -> dialog.dismiss())
            .show();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if(photoPickerCallback!=null){photoPickerCallback.onReceiveValue(null);photoPickerCallback=null;}
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
