# واژه‌چین نسخه ۴.۱ — صفحه اصلی همیشگی

- بازی همیشه با همان صفحه اصلی اصلی، حتی بدون اینترنت باز می‌شود.
- فقط با لمس تب **آنلاین**، یک اتصال جداگانه به سرور برقرار می‌شود.
- قطع اینترنت: روی همان صفحه اصلی پیام «اینترنت شما قطع است» ظاهر می‌شود و کاربر به صفحه خطای تمام‌صفحه منتقل نمی‌شود.
- خطا/قطعی VPN/خواب سرور: پیام خطای ارتباط با سرور و دو انتخاب تلاش دوباره یا بازگشت.
- در اتصال موفق فقط صفحه سرور واقعی باز می‌شود، همراه با بازگشت به صفحه اصلی.
- بازی مرحله‌ای، دونفره محلی، حساب نمایشی، کیف پول نمایشی و سکه‌های محلی مستقل از ارتباط شبکه می‌مانند.
- مسابقه آنلاین ۲۰ تصویر با ۴۰ ثانیه برای هر تصویر دارد و نیازمند دو دستگاه متصل است.
- هیچ مبلغ واقعی پرداخت یا برداشت نمی‌شود.

ساخت: فایل `vazhehchin-android-project-11.zip` را به مخزن Github آپلود کن و در `.github/workflows/build-apk.yml` خط `unzip` را از `project-10.zip` به `project-11.zip` تغییر بده.
نسخه ۴.۱.۰، کد ۴۱، شناسه همان `ir.vazhehchin.game` است.


## v4.2 account routing
The bundled offline home is always available. The Account tab opens the real
online server page in the dedicated remote WebView, using server-managed
account endpoints rather than the bundled HTML local demo. On network
failure the user is returned to the original home. NOTE: the existing backend
stores user data on the Render instance's ephemeral filesystem, does NOT
verify phone numbers by SMS, and is not a production-grade durable identity
service. Integrate a durable database and phone/email verification before
marketing accounts as fully verified and persistent.


## نسخهٔ ۴.۳ — ثبت‌نام با موبایل و رمز (بدون پیامک)

- صفحهٔ اصلی و بازی تک‌نفره در حالت آفلاین می‌مانند.
- لمس «حساب من» منحصراً به WebView سرور HTTPS منتقل می‌شود، نه حساب تمرینی داخل HTML آفلاین.
- WebView فقط پس از احراز برچسب `data-server-backend=true` صفحهٔ حساب را نشان می‌دهد.
- ثبت‌نام با نام نمایشی، شمارهٔ موبایل و رمز دلخواه (حداقل ۸ نویسه) انجام می‌شود.
- ورود با شمارهٔ موبایل و همان رمز؛ گذرواژه فقط به API HTTPS ارسال می‌شود و در سرور با scrypt + نمک هش می‌شود.
- رمز را در این برنامه با SMS تأیید نمی‌کنیم؛ شمارهٔ کاربر احراز نشده است.
- سرور فعلی روی Render فایل JSON را در سیستم فایل موقت نگه می‌دارد. برای نگهداری دائمی حساب‌ها باید DATA_DIR را روی دیسک دائمی Render قرار داد، یا از یک پایگاه دادهٔ مدیریت‌شده استفاده کرد. نسخهٔ فعلی ذخیرهٔ دائم تضمین‌شده ندارد.
- فایل پروژه را به `vazhehchin-android-project-13.zip` تبدیل و خط unzip در `.github/workflows/build-apk.yml` را به آن نام تغییر دهید.
